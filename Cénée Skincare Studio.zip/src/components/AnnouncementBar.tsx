export function AnnouncementBar() {
  const messages = [
    "Order ahead — collect at the window in under 5 minutes",
    "Free kulhad chai on orders over $25",
    "Riverside Lane now open until 11pm",
    "Freshly fried, never held under a lamp",
  ];
  const repeated = [...messages, ...messages];
  return (
    <div className="bg-ink text-white overflow-hidden border-b border-white/10">
      <div className="flex animate-marquee whitespace-nowrap py-2.5 w-max">
        {repeated.map((m, i) => (
          <span
            key={i}
            className="px-10 text-[10px] font-medium tracked"
            aria-hidden={i >= messages.length}
          >
            {m} <span className="ml-10 text-ember">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
