import { useEffect } from "react";
import { X, Minus, Plus, Car, Clock } from "lucide-react";
import { useCart, formatPrice, LANES, PICKUP_SLOTS } from "@/lib/cart-context";
import { products } from "@/lib/products";

const FREE_CHAI_THRESHOLD = 25;
const FREE_SWEET_THRESHOLD = 40;

export function CartDrawer() {
  const {
    isOpen,
    closeCart,
    items,
    subtotal,
    setQty,
    remove,
    add,
    lane,
    setLane,
    slot,
    setSlot,
    prepMinutes,
  } = useCart();

  useEffect(() => {
    if (isOpen) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const target = subtotal >= FREE_CHAI_THRESHOLD ? FREE_SWEET_THRESHOLD : FREE_CHAI_THRESHOLD;
  const targetLabel =
    subtotal >= FREE_CHAI_THRESHOLD ? "a free gulab jamun" : "a free kulhad chai";
  const remaining = Math.max(0, target - subtotal);
  const progress = Math.min(100, (subtotal / target) * 100);
  const reached = remaining === 0;

  const suggestions = products
    .filter((p) => !items.find((i) => i.product.slug === p.slug))
    .slice(0, 3);

  return (
    <div className="fixed inset-0 z-[100]">
      <button
        aria-label="Close order"
        onClick={closeCart}
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm animate-overlay-in"
      />
      <aside className="absolute right-0 top-0 h-full w-full max-w-[470px] bg-background flex flex-col animate-drawer-in shadow-2xl">
        <div className="p-6 border-b border-border flex justify-between items-center">
          <h3 className="text-[11px] tracked font-semibold">
            Your Order ({items.length})
          </h3>
          <button
            onClick={closeCart}
            aria-label="Close"
            className="size-8 grid place-items-center hover:rotate-90 transition-transform duration-300"
          >
            <X size={18} strokeWidth={1.25} />
          </button>
        </div>

        {/* Pickup controls */}
        <div className="p-6 border-b border-border space-y-5 bg-cream/60">
          <div>
            <p className="text-[9.5px] tracked text-muted-foreground mb-2.5 flex items-center gap-2">
              <Car size={12} strokeWidth={1.5} /> Pick-up lane
            </p>
            <div className="grid gap-2">
              {LANES.map((l) => (
                <button
                  key={l.id}
                  onClick={() => setLane(l.id)}
                  className={`text-left px-3.5 py-2.5 border transition-colors ${
                    lane === l.id
                      ? "border-ink bg-ink text-white"
                      : "border-border bg-background hover:border-ink"
                  }`}
                >
                  <span className="text-[11.5px] font-medium block">{l.name}</span>
                  <span
                    className={`text-[9.5px] ${lane === l.id ? "text-white/60" : "text-muted-foreground"}`}
                  >
                    {l.detail}
                  </span>
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="text-[9.5px] tracked text-muted-foreground mb-2.5 flex items-center gap-2">
              <Clock size={12} strokeWidth={1.5} /> Collect
            </p>
            <div className="flex flex-wrap gap-2">
              {PICKUP_SLOTS.map((s) => (
                <button
                  key={s}
                  onClick={() => setSlot(s)}
                  className={`text-[10px] tracked px-3 py-2 border transition-colors ${
                    slot === s
                      ? "border-clay bg-clay text-white"
                      : "border-border hover:border-clay"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 bg-sand/50 border-b border-border">
          <p className="text-[10.5px] tracked mb-3">
            {reached ? (
              <span className="font-semibold">Unlocked — {targetLabel} is on us</span>
            ) : (
              <>
                Add <span className="font-semibold">{formatPrice(remaining)}</span> more for {targetLabel}
              </>
            )}
          </p>
          <div className="w-full h-[3px] bg-ink/10 overflow-hidden">
            <div
              className="h-full bg-clay transition-all duration-700 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {items.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-display italic text-2xl mb-3">Nothing in the bag yet</p>
              <p className="text-sm text-muted-foreground">
                Start with a kadak chai — everything else follows.
              </p>
            </div>
          ) : (
            <ul className="space-y-8">
              {items.map(({ product, qty }) => (
                <li key={product.slug} className="flex gap-5">
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    width={96}
                    height={120}
                    loading="lazy"
                    className="w-24 h-30 object-cover bg-cream shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-medium">{product.name}</h4>
                    <p className="text-[10.5px] tracked text-muted-foreground mt-1">
                      {product.serving}
                    </p>
                    <div className="flex justify-between items-end mt-5">
                      <div className="flex items-center border border-border">
                        <button
                          onClick={() => setQty(product.slug, qty - 1)}
                          className="px-2.5 py-1.5 hover:bg-cream"
                          aria-label="Decrease"
                        >
                          <Minus size={11} strokeWidth={1.5} />
                        </button>
                        <span className="px-3 text-xs tabular-nums">{qty}</span>
                        <button
                          onClick={() => setQty(product.slug, qty + 1)}
                          className="px-2.5 py-1.5 hover:bg-cream"
                          aria-label="Increase"
                        >
                          <Plus size={11} strokeWidth={1.5} />
                        </button>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">{formatPrice(product.price * qty)}</p>
                        <button
                          onClick={() => remove(product.slug)}
                          className="text-[9.5px] tracked text-muted-foreground underline mt-1 hover:text-clay"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {suggestions.length > 0 && (
            <div className="mt-14">
              <h5 className="text-[10px] tracked font-semibold text-muted-foreground mb-5">
                Add to the window run
              </h5>
              <ul className="space-y-3">
                {suggestions.map((p) => (
                  <li key={p.slug} className="bg-cream p-3 flex items-center gap-4">
                    <img
                      src={p.images[0]}
                      alt={p.name}
                      width={48}
                      height={48}
                      loading="lazy"
                      className="size-12 object-cover bg-background shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-medium truncate">{p.name}</p>
                      <p className="text-[10px] text-muted-foreground">{formatPrice(p.price)}</p>
                    </div>
                    <button
                      onClick={() => add(p)}
                      className="text-[9.5px] tracked border border-ink px-3 py-1.5 hover:bg-ink hover:text-white transition-colors"
                    >
                      Add
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-border space-y-4">
          {items.length > 0 && (
            <div className="flex justify-between text-[10px] tracked text-muted-foreground">
              <span>Kitchen time</span>
              <span>~{prepMinutes} min · {slot}</span>
            </div>
          )}
          <div className="flex justify-between text-[11px] tracked font-semibold">
            <span>Subtotal</span>
            <span className="tabular-nums">{formatPrice(subtotal)}</span>
          </div>
          <button
            disabled={items.length === 0}
            className="w-full bg-ink text-white py-4 text-[11px] tracked font-semibold hover:bg-clay transition-colors disabled:opacity-40"
          >
            Confirm drive-thru order
          </button>
          <p className="text-[10px] text-muted-foreground text-center">
            Pay at the window · Taxes included
          </p>
        </div>
      </aside>
    </div>
  );
}
