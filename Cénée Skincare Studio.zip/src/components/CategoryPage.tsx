import { SiteLayout } from "./SiteLayout";
import { ProductCard } from "./ProductCard";
import { getProductsByCategory, type Category } from "@/lib/products";

const META: Record<Category, { index: string; title: string; intro: string }> = {
  chai: {
    index: "01",
    title: "Chai & Brews",
    intro:
      "Leaf boiled the long way, milk reduced, spices ground the morning of. Every cup is built to survive a commute — double-walled, lidded, cup-holder true.",
  },
  plates: {
    index: "02",
    title: "Hot Plates",
    intro:
      "Dosa off the tawa, khichdi off the stove, rolls off the grill. Packed in compartment boxes so nothing goes soft between the window and your table.",
  },
  snacks: {
    index: "03",
    title: "Quick Bites",
    intro:
      "Fried to order, never held under a lamp. The things you eat with one hand while the light is still red.",
  },
  sweets: {
    index: "04",
    title: "Sweets & Coolers",
    intro:
      "Lassi thick enough for a wide straw, kulfi that survives the drive, and jamun still warm in its pot.",
  },
};

export function CategoryPage({ category }: { category: Category }) {
  const products = getProductsByCategory(category);
  const meta = META[category];
  return (
    <SiteLayout>
      <section className="border-b border-border bg-cream/60">
        <div className="max-w-[1400px] mx-auto px-6 py-20 lg:py-28 grid grid-cols-1 lg:grid-cols-[1fr_2fr] gap-12 items-end">
          <div className="animate-fade-up">
            <p className="text-[10px] tracked text-muted-foreground mb-4">
              {meta.index} — Menu board
            </p>
            <h1 className="font-display italic text-6xl lg:text-8xl leading-none">
              {meta.title}
            </h1>
          </div>
          <p className="text-sm lg:text-base text-muted-foreground leading-relaxed max-w-2xl animate-fade-up [animation-delay:150ms]">
            {meta.intro}
          </p>
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 py-20">
        <div className="flex justify-between items-center mb-12 pb-5 border-b border-border">
          <p className="text-[10.5px] tracked">
            {products.length} item{products.length > 1 ? "s" : ""}
          </p>
          <p className="text-[10.5px] tracked text-muted-foreground">
            Ready at the window in minutes
          </p>
        </div>
        {products.length === 0 ? (
          <p className="font-display italic text-3xl text-center py-20">Coming soon.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-16">
            {products.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
