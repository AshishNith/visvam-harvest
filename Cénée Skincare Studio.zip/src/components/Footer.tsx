import { Link } from "@tanstack/react-router";
import { LANES } from "@/lib/cart-context";
import logo from "@/assets/visvam-logo.png";

export function Footer() {
  return (
    <footer className="bg-cream pt-24 pb-12 border-t border-border">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 mb-20">
          <div className="max-w-md">
            <h3 className="font-display italic text-3xl mb-6">Skip the queue entirely.</h3>
            <p className="text-sm text-muted-foreground mb-8 leading-relaxed">
              Join the lane list for new menu drops, seasonal specials and a free chai
              on your birthday.
            </p>
            <form className="flex border-b border-ink" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                required
                placeholder="Your email"
                className="flex-1 py-3 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
              />
              <button className="text-[10px] tracked font-semibold hover:text-clay transition">
                Join
              </button>
            </form>
          </div>

          <div className="grid grid-cols-3 gap-10">
            <div className="space-y-4">
              <h6 className="text-[10px] tracked font-semibold">Menu</h6>
              <ul className="space-y-2.5 text-[11px]">
                <li><Link to="/chai" className="hover:text-clay">Chai & Brews</Link></li>
                <li><Link to="/plates" className="hover:text-clay">Hot Plates</Link></li>
                <li><Link to="/snacks" className="hover:text-clay">Quick Bites</Link></li>
                <li><Link to="/sweets" className="hover:text-clay">Sweets & Coolers</Link></li>
                <li><Link to="/combos" className="hover:text-clay">Combos & Offers</Link></li>
              </ul>
            </div>
            <div className="space-y-4">
              <h6 className="text-[10px] tracked font-semibold">Lanes</h6>
              <ul className="space-y-2.5 text-[11px]">
                {LANES.map((l) => (
                  <li key={l.id} className="text-muted-foreground">
                    <span className="text-ink">{l.name}</span>
                    <br />
                    {l.detail}
                  </li>
                ))}
              </ul>
            </div>
            <div className="space-y-4">
              <h6 className="text-[10px] tracked font-semibold">Kitchen</h6>
              <ul className="space-y-2.5 text-[11px]">
                <li><Link to="/story" className="hover:text-clay">Our Story</Link></li>
                <li><a className="hover:text-clay" href="#">Allergens</a></li>
                <li><a className="hover:text-clay" href="#">Catering</a></li>
                <li><a className="hover:text-clay" href="#">Work with us</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-border flex flex-col md:flex-row justify-between items-center gap-6">
          <img
            src={logo}
            alt="Viśvam"
            width={120}
            height={120}
            loading="lazy"
            className="h-12 w-auto object-contain mix-blend-multiply"
          />
          <div className="text-[9px] tracked text-muted-foreground">
            © 2026 Viśvam Drive-Thru — Cooked to order, handed through the window
          </div>
          <div className="flex items-center gap-6 text-[10px] tracked">
            <a href="#" className="hover:text-clay">Instagram</a>
            <a href="#" className="hover:text-clay">TikTok</a>
            <a href="#" className="hover:text-clay">Careers</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
