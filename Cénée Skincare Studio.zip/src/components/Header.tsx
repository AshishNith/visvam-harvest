import { Link } from "@tanstack/react-router";
import { Search, User, MapPin } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import logo from "@/assets/visvam-logo.png";

const links = [
  { to: "/chai", label: "Chai" },
  { to: "/plates", label: "Plates" },
  { to: "/snacks", label: "Bites" },
  { to: "/sweets", label: "Sweets" },
] as const;

const rightLinks = [
  { to: "/combos", label: "Combos" },
  { to: "/story", label: "Our Story" },
] as const;

export function Header() {
  const { count, openCart } = useCart();
  return (
    <header className="bg-background/90 backdrop-blur-md border-b border-border">
      <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-[1fr_auto_1fr] items-center h-20 gap-6">
        <nav className="hidden lg:flex items-center gap-8 text-[10.5px] font-medium tracked">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="hover:text-clay transition-colors"
              activeProps={{ className: "text-clay" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <Link to="/" className="flex items-center gap-3 justify-center">
          <img
            src={logo}
            alt="Viśvam drive-thru logo"
            width={120}
            height={120}
            className="h-11 w-auto object-contain mix-blend-multiply"
          />
        </Link>

        <div className="flex items-center justify-end gap-6">
          <nav className="hidden lg:flex items-center gap-8 text-[10.5px] font-medium tracked mr-2">
            {rightLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="hover:text-clay transition-colors"
                activeProps={{ className: "text-clay" }}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="hidden xl:flex items-center gap-1.5 text-[10px] tracked border border-border px-3 py-1">
            <MapPin size={11} strokeWidth={1.5} />
            Riverside Lane
          </div>
          <button aria-label="Search the menu" className="p-1 hover:text-clay">
            <Search size={16} strokeWidth={1.25} />
          </button>
          <button aria-label="Account" className="p-1 hover:text-clay">
            <User size={16} strokeWidth={1.25} />
          </button>
          <button
            onClick={openCart}
            className="text-[10.5px] tracked font-medium relative group pl-1"
          >
            Order ({count})
            <span className="absolute -bottom-1 left-1 w-0 h-px bg-clay transition-all duration-300 group-hover:w-[calc(100%-4px)]" />
          </button>
        </div>
      </div>
    </header>
  );
}
