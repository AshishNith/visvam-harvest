import { Link } from "@tanstack/react-router";
import { useCart, formatPrice } from "@/lib/cart-context";
import type { Product } from "@/lib/products";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  return (
    <article className="group">
      <Link
        to="/menu/$slug"
        params={{ slug: product.slug }}
        className="block relative aspect-[3/4] mb-6 overflow-hidden bg-cream"
      >
        {product.badge && (
          <div className="absolute top-4 left-4 z-10">
            <span
              className={`text-[9px] tracked px-2.5 py-1 ${
                product.isNew || product.badge.startsWith("-")
                  ? "bg-ink text-white"
                  : "bg-white text-ink"
              }`}
            >
              {product.badge}
            </span>
          </div>
        )}
        <img
          src={product.images[0]}
          alt={product.name}
          width={912}
          height={1200}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover transition-all duration-[900ms] ease-out group-hover:opacity-0 group-hover:scale-[1.04]"
        />
        <img
          src={product.images[1] ?? product.images[0]}
          alt={`${product.name} detail`}
          width={912}
          height={1200}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover opacity-0 scale-[1.06] transition-all duration-[900ms] ease-out group-hover:opacity-100 group-hover:scale-100"
        />
        <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between bg-ink text-white py-3.5 px-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <span className="text-[10px] tracked">{product.prepMinutes} min</span>
          <button
            onClick={(e) => {
              e.preventDefault();
              add(product);
            }}
            className="text-[10px] tracked font-semibold hover:text-sand"
          >
            Add to order +
          </button>
        </div>
      </Link>
      <div className="space-y-1.5">
        <h4 className="text-sm font-medium">
          <Link to="/menu/$slug" params={{ slug: product.slug }} className="hover:opacity-50">
            {product.name}
          </Link>
        </h4>
        <p className="text-[10.5px] text-muted-foreground tracked">{product.tagline}</p>
        <p className="text-sm tabular-nums">{formatPrice(product.price)}</p>
      </div>
    </article>
  );
}
