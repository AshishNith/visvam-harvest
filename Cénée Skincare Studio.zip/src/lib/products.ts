import chai1 from "@/assets/masala-chai-1.jpg";
import chai2 from "@/assets/masala-chai-2.jpg";
import chai3 from "@/assets/masala-chai-3.jpg";
import badam1 from "@/assets/badam-milk-1.jpg";
import badam2 from "@/assets/badam-milk-2.jpg";
import badam3 from "@/assets/badam-milk-3.jpg";
import latte1 from "@/assets/golden-latte-1.jpg";
import latte2 from "@/assets/golden-latte-2.jpg";
import latte3 from "@/assets/golden-latte-3.jpg";
import dosa1 from "@/assets/masala-dosa-1.jpg";
import dosa2 from "@/assets/masala-dosa-2.jpg";
import dosa3 from "@/assets/masala-dosa-3.jpg";
import khichdi1 from "@/assets/khichdi-1.jpg";
import khichdi2 from "@/assets/khichdi-2.jpg";
import khichdi3 from "@/assets/khichdi-3.jpg";
import roll1 from "@/assets/kathi-roll-1.jpg";
import roll2 from "@/assets/kathi-roll-2.jpg";
import roll3 from "@/assets/kathi-roll-3.jpg";
import samosa1 from "@/assets/samosa-1.jpg";
import samosa2 from "@/assets/samosa-2.jpg";
import samosa3 from "@/assets/samosa-3.jpg";
import vada1 from "@/assets/vada-pav-1.jpg";
import vada2 from "@/assets/vada-pav-2.jpg";
import vada3 from "@/assets/vada-pav-3.jpg";
import corn1 from "@/assets/masala-corn-1.jpg";
import corn2 from "@/assets/masala-corn-2.jpg";
import corn3 from "@/assets/masala-corn-3.jpg";
import lassi1 from "@/assets/mango-lassi-1.jpg";
import lassi2 from "@/assets/mango-lassi-2.jpg";
import lassi3 from "@/assets/mango-lassi-3.jpg";
import jamun1 from "@/assets/gulab-jamun-1.jpg";
import jamun2 from "@/assets/gulab-jamun-2.jpg";
import jamun3 from "@/assets/gulab-jamun-3.jpg";
import kulfi1 from "@/assets/kulfi-1.jpg";
import kulfi2 from "@/assets/kulfi-2.jpg";
import kulfi3 from "@/assets/kulfi-3.jpg";

export type Category = "chai" | "plates" | "snacks" | "sweets";

export type Product = {
  slug: string;
  name: string;
  tagline: string;
  price: number;
  category: Category;
  badge?: string;
  images: string[];
  description: string;
  serving: string;
  prepMinutes: number;
  spice?: "mild" | "medium" | "hot";
  bestseller?: boolean;
  isNew?: boolean;
};

export const products: Product[] = [
  {
    slug: "masala-chai",
    name: "Kadak Masala Chai",
    tagline: "Cardamom · Ginger · Assam leaf",
    price: 3.5,
    category: "chai",
    badge: "Lane favourite",
    images: [chai1, chai2, chai3],
    description:
      "Assam leaf boiled the long way with fresh ginger, green cardamom and a whisper of clove. Poured hot into a double-walled cup that fits every cup holder we have ever tested.",
    serving: "12 oz",
    prepMinutes: 2,
    spice: "mild",
    bestseller: true,
  },
  {
    slug: "saffron-badam-milk",
    name: "Saffron Badam Milk",
    tagline: "Kashmiri saffron · Slow-ground almond",
    price: 4.75,
    category: "chai",
    badge: "New",
    images: [badam1, badam2, badam3],
    description:
      "Whole almonds stone-ground into milk, warmed with saffron and a pinch of nutmeg. Served hot in winter, chilled over ice all summer. No syrups, no shortcuts.",
    serving: "12 oz",
    prepMinutes: 3,
    isNew: true,
    bestseller: true,
  },
  {
    slug: "golden-turmeric-latte",
    name: "Golden Turmeric Latte",
    tagline: "Turmeric · Black pepper · Cinnamon",
    price: 4.25,
    category: "chai",
    images: [latte1, latte2, latte3],
    description:
      "Fresh turmeric root pressed to order, balanced with black pepper for absorption and cinnamon for warmth. The calmest thing on the menu board.",
    serving: "12 oz",
    prepMinutes: 3,
    spice: "mild",
  },
  {
    slug: "masala-dosa",
    name: "Ghee Masala Dosa",
    tagline: "36-hour batter · Potato masala",
    price: 9.5,
    category: "plates",
    badge: "Lane favourite",
    images: [dosa1, dosa2, dosa3],
    description:
      "Rice and urad batter fermented for thirty-six hours, crisped on a cast iron tawa in ghee and rolled around a soft potato masala. Sambar and two chutneys in spill-proof cups.",
    serving: "1 dosa + 3 sides",
    prepMinutes: 7,
    spice: "medium",
    bestseller: true,
  },
  {
    slug: "ghee-khichdi-bowl",
    name: "Ghee Khichdi Bowl",
    tagline: "Moong dal · Aged rice · Cumin",
    price: 8.5,
    category: "plates",
    images: [khichdi1, khichdi2, khichdi3],
    description:
      "The bowl we make when someone needs looking after. Moong dal and aged rice cooked soft, finished with cumin-tempered ghee, yoghurt and pickle on the side.",
    serving: "16 oz bowl",
    prepMinutes: 5,
    spice: "mild",
  },
  {
    slug: "paneer-kathi-roll",
    name: "Paneer Kathi Roll",
    tagline: "Charred paneer · Mint chutney",
    price: 9.0,
    category: "plates",
    badge: "One-hand friendly",
    images: [roll1, roll2, roll3],
    description:
      "Paneer marinated overnight, charred hard on the grill and rolled into a flaky paratha with sharp onion and mint chutney. Wrapped so it never drips on the steering wheel.",
    serving: "1 roll",
    prepMinutes: 6,
    spice: "medium",
    bestseller: true,
  },
  {
    slug: "samosa-duo",
    name: "Samosa Duo",
    tagline: "Potato · Pea · Two chutneys",
    price: 5.5,
    category: "snacks",
    images: [samosa1, samosa2, samosa3],
    description:
      "Two hand-folded samosas fried to order, so the shell shatters instead of bending. Tamarind and coriander chutney included, no upcharge.",
    serving: "2 pieces",
    prepMinutes: 5,
    spice: "medium",
  },
  {
    slug: "vada-pav",
    name: "Bombay Vada Pav",
    tagline: "Potato vada · Dry garlic chutney",
    price: 6.0,
    category: "snacks",
    badge: "-10%",
    images: [vada1, vada2, vada3],
    description:
      "A soft pav split and lined with green chutney and dry garlic chutney, packed around a just-fried potato vada. The original drive-away sandwich, sixty years before we built a lane.",
    serving: "1 piece",
    prepMinutes: 4,
    spice: "hot",
  },
  {
    slug: "masala-sweet-corn",
    name: "Masala Sweet Corn",
    tagline: "Butter · Chaat masala · Lime",
    price: 4.5,
    category: "snacks",
    images: [corn1, corn2, corn3],
    description:
      "Steamed sweet corn tossed with butter, chaat masala, chilli and a hard squeeze of lime. Comes in a cup-holder cup with a wooden spoon.",
    serving: "10 oz cup",
    prepMinutes: 3,
    spice: "medium",
  },
  {
    slug: "mango-lassi",
    name: "Alphonso Mango Lassi",
    tagline: "Alphonso pulp · Set curd",
    price: 5.25,
    category: "sweets",
    badge: "Seasonal",
    images: [lassi1, lassi2, lassi3],
    description:
      "House-set curd blended thick with Alphonso pulp and a spoon of cream, finished with saffron and crushed pistachio. Thick enough to need the wide straw.",
    serving: "16 oz",
    prepMinutes: 2,
    bestseller: true,
  },
  {
    slug: "gulab-jamun",
    name: "Warm Gulab Jamun",
    tagline: "Khoya · Rose · Cardamom syrup",
    price: 4.5,
    category: "sweets",
    images: [jamun1, jamun2, jamun3],
    description:
      "Khoya dumplings fried dark and rested in cardamom-rose syrup until they give way under a spoon. Served warm in a lidded pot, two to an order.",
    serving: "2 pieces",
    prepMinutes: 2,
  },
  {
    slug: "kesar-pista-kulfi",
    name: "Kesar Pista Kulfi",
    tagline: "Reduced milk · Saffron · Pistachio",
    price: 4.75,
    category: "sweets",
    badge: "New",
    images: [kulfi1, kulfi2, kulfi3],
    description:
      "Milk reduced for four hours, set on a stick with saffron and coarsely crushed pistachio. Denser than ice cream, and it holds up to a long drive home.",
    serving: "1 bar",
    prepMinutes: 1,
    isNew: true,
  },
];

export const getProductsByCategory = (c: Category) =>
  products.filter((p) => p.category === c);

export const getProductBySlug = (slug: string) =>
  products.find((p) => p.slug === slug);

export const categories: { slug: Category; label: string; index: string }[] = [
  { slug: "chai", label: "Chai & Brews", index: "01" },
  { slug: "plates", label: "Hot Plates", index: "02" },
  { slug: "snacks", label: "Quick Bites", index: "03" },
  { slug: "sweets", label: "Sweets & Coolers", index: "04" },
];
