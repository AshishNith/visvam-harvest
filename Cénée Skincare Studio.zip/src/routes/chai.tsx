import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/chai")({
  head: () => ({
    meta: [
      { title: "Chai & Brews — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Kadak masala chai, saffron badam milk and golden turmeric lattes, boiled fresh and handed through the Viśvam drive-thru window.",
      },
      { property: "og:title", content: "Chai & Brews — Viśvam Drive-Thru" },
      { property: "og:description", content: "Slow-boiled chai, ready at the window." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <CategoryPage category="chai" />,
});
