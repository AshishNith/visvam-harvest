import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { ProductCard } from "@/components/ProductCard";
import { useCart, formatPrice } from "@/lib/cart-context";
import { products } from "@/lib/products";
import comboImg from "@/assets/combo-box.jpg";

export const Route = createFileRoute("/combos")({
  head: () => ({
    meta: [
      { title: "Combos & Offers — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Build the window run: chai, samosa and roll combo boxes plus this week's discounted bites at Viśvam Drive-Thru.",
      },
      { property: "og:title", content: "Combos & Offers — Viśvam Drive-Thru" },
      { property: "og:description", content: "Combo boxes and weekly offers at the window." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Combos,
});

function Combos() {
  const { add } = useCart();
  const promo = products.filter((p) => p.badge?.startsWith("-"));
  const comboItems = [
    products.find((p) => p.slug === "masala-chai")!,
    products.find((p) => p.slug === "samosa-duo")!,
    products.find((p) => p.slug === "paneer-kathi-roll")!,
  ];
  const comboTotal = comboItems.reduce((s, p) => s + p.price, 0);
  const comboPrice = Math.round((comboTotal * 0.85 + Number.EPSILON) * 100) / 100;

  return (
    <SiteLayout>
      <section className="border-b border-border bg-cream/60">
        <div className="max-w-[1400px] mx-auto px-6 py-20 lg:py-28">
          <p className="text-[10px] tracked text-muted-foreground mb-4">— The window run</p>
          <h1 className="font-display italic text-6xl lg:text-8xl leading-none animate-fade-up">
            Combos & Offers
          </h1>
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 py-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-stretch">
        <div className="bg-cream relative overflow-hidden aspect-[5/4] lg:aspect-auto group">
          <img
            src={comboImg}
            alt="Viśvam chai, samosa and roll combo box"
            width={1408}
            height={1008}
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-[900ms]"
          />
          <div className="absolute top-5 left-5 flex flex-col gap-2">
            <span className="bg-ink text-white text-[9px] tracked px-2.5 py-1">Save 15%</span>
            <span className="bg-white text-ink text-[9px] tracked px-2.5 py-1">One box, one hand</span>
          </div>
        </div>
        <div className="flex flex-col justify-center py-6">
          <p className="text-[10px] tracked text-muted-foreground mb-4">— Combo N°1</p>
          <h2 className="font-display italic text-4xl mb-6">Chai. Samosa. Roll.</h2>
          <p className="text-sm text-muted-foreground mb-8 max-w-md leading-relaxed">
            The order two out of three cars place. Packed into one compartment box that
            sits flat on a passenger seat and stays hot for the drive home.
          </p>
          <div className="space-y-3 mb-8">
            {comboItems.map((p) => (
              <div
                key={p.slug}
                className="flex justify-between text-[12.5px] border-b border-border pb-3"
              >
                <span>{p.name}</span>
                <span className="text-muted-foreground tabular-nums">{formatPrice(p.price)}</span>
              </div>
            ))}
          </div>
          <div className="flex items-baseline gap-4 mb-8">
            <span className="text-[10px] tracked">Combo price</span>
            <span className="font-display italic text-3xl">{formatPrice(comboPrice)}</span>
            <span className="text-[11px] text-muted-foreground line-through tabular-nums">
              {formatPrice(comboTotal)}
            </span>
          </div>
          <button
            onClick={() => comboItems.forEach(add)}
            className="self-start bg-ink text-white px-10 py-4 text-[11px] tracked font-semibold hover:bg-clay transition-colors"
          >
            Add the combo
          </button>
        </div>
      </section>

      {promo.length > 0 && (
        <section className="max-w-[1400px] mx-auto px-6 py-20 border-t border-border">
          <h2 className="font-display italic text-4xl mb-12">This week at the window</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-16">
            {promo.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </section>
      )}

      <section className="bg-ink text-white py-20 text-center">
        <p className="text-[10px] tracked text-white/60 mb-4">— Lane Club</p>
        <h2 className="font-display italic text-4xl md:text-5xl max-w-2xl mx-auto px-6 mb-8">
          Ten runs through the lane. The eleventh chai is ours.
        </h2>
        <Link
          to="/story"
          className="inline-block bg-white text-ink px-10 py-4 text-[11px] tracked font-semibold hover:bg-sand transition-colors"
        >
          How it works
        </Link>
      </section>
    </SiteLayout>
  );
}
