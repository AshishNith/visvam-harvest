import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { ProductCard } from "@/components/ProductCard";
import { useCart, formatPrice, LANES } from "@/lib/cart-context";
import { products, categories } from "@/lib/products";
import heroImg from "@/assets/hero-drive-thru.jpg";
import comboImg from "@/assets/combo-box.jpg";
import editorialImg from "@/assets/editorial-kitchen.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Viśvam Drive-Thru — Indian kitchen at the window" },
      {
        name: "description",
        content:
          "Viśvam Drive-Thru serves slow-cooked Indian food at drive-thru speed — kadak chai, ghee dosa, kathi rolls and kulfi, ready at the window in minutes.",
      },
      { property: "og:title", content: "Viśvam Drive-Thru — Indian kitchen at the window" },
      {
        property: "og:description",
        content: "Chai boiled, dosa crisped, rolls grilled — collected without leaving the car.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const bestsellers = products.filter((p) => p.bestseller);
  const { add } = useCart();
  const comboItems = [
    products.find((p) => p.slug === "masala-chai")!,
    products.find((p) => p.slug === "samosa-duo")!,
    products.find((p) => p.slug === "paneer-kathi-roll")!,
  ];
  const comboTotal = comboItems.reduce((s, p) => s + p.price, 0);

  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative h-[88vh] overflow-hidden bg-cream">
        <img
          src={heroImg}
          alt="A cup of chai handed through the Viśvam drive-thru window at golden hour"
          width={1920}
          height={1280}
          className="absolute inset-0 w-full h-full object-cover animate-fade-in"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-ink/15 to-transparent" />
        <div className="absolute inset-0 flex flex-col items-center justify-end pb-24 text-center px-6">
          <p className="text-[10px] tracked text-white/80 mb-6 animate-fade-up [animation-delay:200ms] flex items-center gap-3">
            <span className="size-1.5 rounded-full bg-ember animate-lane-pulse" />
            Three lanes open now
          </p>
          <h1 className="font-display italic text-white text-5xl md:text-7xl lg:text-[92px] font-normal leading-[0.95] mb-8 animate-fade-up max-w-4xl">
            Chai boiled slow.<br />Handed over fast.
          </h1>
          <p className="text-white/85 text-sm max-w-md mb-10 animate-fade-up [animation-delay:300ms]">
            An Indian kitchen built behind a drive-thru window. Order ahead, pull in,
            and take it away still steaming.
          </p>
          <div className="flex flex-wrap justify-center gap-3 animate-fade-up [animation-delay:500ms]">
            <Link
              to="/chai"
              className="inline-block bg-white text-ink px-12 py-4 text-[11px] tracked font-semibold hover:bg-clay hover:text-white transition-colors duration-500"
            >
              Start an order
            </Link>
            <Link
              to="/combos"
              className="inline-block border border-white/60 text-white px-12 py-4 text-[11px] tracked font-semibold hover:bg-white hover:text-ink transition-colors duration-500"
            >
              See combos
            </Link>
          </div>
        </div>
      </section>

      {/* How the lane works */}
      <section className="border-b border-border py-16 bg-background">
        <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-10">
          {[
            ["01", "Order ahead", "Build your bag online or at the board."],
            ["02", "Pick your lane", "Riverside, Northgate or Mill Yard."],
            ["03", "Pull in", "Give the name at the speaker post."],
            ["04", "Drive on", "Hot food through the window in under 5 min."],
          ].map(([index, title, body]) => (
            <div key={index} className="space-y-3.5 group">
              <p className="font-display italic text-3xl text-clay group-hover:translate-x-1 transition-transform duration-500">
                {index}
              </p>
              <h5 className="text-[10px] tracked font-semibold">{title}</h5>
              <p className="text-[11px] text-muted-foreground leading-relaxed max-w-[24ch]">
                {body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Bestsellers */}
      <section className="py-24 bg-cream/50">
        <div className="max-w-[1400px] mx-auto px-6">
          <div className="flex justify-between items-end mb-14">
            <div>
              <p className="text-[10px] tracked text-muted-foreground mb-3">— Most ordered</p>
              <h2 className="font-display italic text-4xl md:text-5xl">The lane favourites</h2>
            </div>
            <Link
              to="/combos"
              className="text-[10.5px] tracked font-medium border-b border-ink pb-1 hover:text-clay hover:border-clay"
            >
              View all
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-16">
            {bestsellers.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Menu board blocks */}
      <section className="max-w-[1400px] mx-auto px-6 py-24">
        <div className="flex justify-between items-end mb-14">
          <h2 className="font-display italic text-4xl md:text-5xl">The menu board</h2>
          <p className="text-[10.5px] tracked text-muted-foreground max-w-xs hidden md:block">
            Four boards — chai, plates, bites, sweets. Twelve things we make properly.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-border border border-border">
          {categories.map((c) => {
            const count = products.filter((p) => p.category === c.slug).length;
            return (
              <Link
                key={c.slug}
                to={`/${c.slug}` as "/chai"}
                className="bg-background aspect-[4/5] p-10 flex flex-col justify-between group relative overflow-hidden hover:bg-cream transition-colors duration-500"
              >
                <span className="text-[10px] tracked text-muted-foreground">
                  {c.index} / {count} items
                </span>
                <div className="flex justify-between items-end">
                  <h3 className="font-display italic text-3xl md:text-4xl group-hover:translate-x-2 transition-transform duration-500">
                    {c.label}
                  </h3>
                  <span className="text-[10px] tracked opacity-0 group-hover:opacity-100 transition-opacity text-clay">
                    →
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Editorial split */}
      <section className="grid grid-cols-1 lg:grid-cols-2 bg-sand/40">
        <div className="relative aspect-[4/5] lg:aspect-auto lg:min-h-[640px]">
          <img
            src={editorialImg}
            alt="Chai pulled between steel pots in the Viśvam kitchen"
            width={1200}
            height={1504}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        <div className="p-10 lg:p-20 flex flex-col justify-center">
          <p className="text-[10px] tracked text-muted-foreground mb-6">— Behind the window</p>
          <h2 className="font-display italic text-4xl md:text-5xl mb-8 leading-tight">
            The kitchen<br />starts at four.
          </h2>
          <p className="text-sm leading-relaxed text-muted-foreground max-w-md mb-10">
            Batter is set the day before. Spices are ground each morning. Chai is pulled
            between pots until the milk carries the cardamom. The window is fast because
            everything behind it was made slowly — three family recipes, one working kitchen,
            no holding lamps anywhere on the line.
          </p>
          <Link
            to="/story"
            className="inline-block self-start border-b border-ink pb-1 text-[10.5px] tracked font-medium hover:text-clay hover:border-clay"
          >
            Read our story
          </Link>
        </div>
      </section>

      {/* Combo builder */}
      <section className="py-24 bg-background">
        <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="bg-cream aspect-[5/4] relative overflow-hidden group">
            <img
              src={comboImg}
              alt="Chai, samosa and kathi roll combo box"
              width={1408}
              height={1008}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-[900ms]"
            />
            <div className="absolute top-5 left-5 flex flex-col gap-2">
              <span className="bg-ink text-white text-[9px] tracked px-2.5 py-1">Save 15%</span>
              <span className="bg-white text-ink text-[9px] tracked px-2.5 py-1">Fits a cup holder</span>
            </div>
          </div>
          <div>
            <p className="text-[10px] tracked text-muted-foreground mb-6">— Combo N°1</p>
            <h2 className="font-display italic text-4xl md:text-5xl mb-6">Build the window run.</h2>
            <p className="text-sm text-muted-foreground mb-8 leading-relaxed max-w-md">
              Chai, samosa and a paneer roll in one compartment box — the order two out
              of three cars place before eight in the morning.
            </p>
            <div className="space-y-3 mb-10">
              {comboItems.map((p) => (
                <div
                  key={p.slug}
                  className="flex justify-between items-center text-[12px] border-b border-border pb-3"
                >
                  <span>{p.name}</span>
                  <span className="text-muted-foreground tabular-nums">
                    {formatPrice(p.price)}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex items-baseline gap-4 mb-8">
              <span className="text-[10px] tracked">Box total</span>
              <span className="font-display italic text-3xl">{formatPrice(comboTotal)}</span>
            </div>
            <button
              onClick={() => comboItems.forEach(add)}
              className="bg-ink text-white px-10 py-4 text-[11px] tracked font-semibold hover:bg-clay transition-colors"
            >
              Add box to order
            </button>
          </div>
        </div>
      </section>

      {/* Lanes */}
      <section className="bg-ink text-white py-24">
        <div className="max-w-[1400px] mx-auto px-6">
          <p className="text-[10px] tracked text-white/60 mb-4">— Find a lane</p>
          <h2 className="font-display italic text-4xl md:text-5xl mb-14">Three windows, one kitchen.</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/15 border border-white/15">
            {LANES.map((l) => (
              <div key={l.id} className="bg-ink p-10 group">
                <div className="flex items-center gap-3 mb-6">
                  <span className="size-1.5 rounded-full bg-ember animate-lane-pulse" />
                  <span className="text-[9.5px] tracked text-white/60">Open now</span>
                </div>
                <h3 className="font-display italic text-3xl mb-3 group-hover:translate-x-1 transition-transform duration-500">
                  {l.name}
                </h3>
                <p className="text-[11.5px] text-white/60">{l.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="bg-cream py-24">
        <div className="max-w-[1400px] mx-auto px-6">
          <div className="text-center mb-14">
            <p className="text-[10px] tracked text-muted-foreground mb-4">— Verified reviews</p>
            <div className="flex items-baseline justify-center gap-3 mb-3">
              <span className="font-display italic text-6xl">4.8</span>
              <span className="text-sm text-muted-foreground">/ 5</span>
            </div>
            <p className="text-[10.5px] tracked">★★★★★ &nbsp;·&nbsp; 2,340 lane reviews</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                initials: "RD",
                name: "Rohan D.",
                title: "Chai that tastes like home",
                body: "I have driven past four coffee chains to get here. The chai is properly boiled and the cup never leaks in the holder.",
              },
              {
                initials: "MK",
                name: "Meera K.",
                title: "The dosa survived the drive",
                body: "Still crisp twenty minutes later, chutney sealed properly. I have no idea how they do it through a window.",
              },
              {
                initials: "TS",
                name: "Tom S.",
                title: "Faster than the coffee queue",
                body: "Ordered ahead at 7:42, collected at 7:47 with a kathi roll and a lassi. Now a three-times-a-week habit.",
              },
            ].map((r) => (
              <article key={r.initials} className="bg-background p-8 border border-border">
                <div className="flex items-center gap-4 mb-5">
                  <div className="size-10 rounded-full bg-sand grid place-items-center text-[11px] font-semibold">
                    {r.initials}
                  </div>
                  <div>
                    <p className="text-[12px] font-medium">{r.name}</p>
                    <p className="text-[9.5px] tracked text-muted-foreground">Verified order</p>
                  </div>
                </div>
                <p className="text-[11px] mb-3 text-clay">★★★★★</p>
                <h5 className="font-medium mb-2">{r.title}</h5>
                <p className="text-[12.5px] text-muted-foreground leading-relaxed">{r.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
