import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { SiteLayout } from "@/components/SiteLayout";
import { ProductCard } from "@/components/ProductCard";
import { useCart, formatPrice } from "@/lib/cart-context";
import { getProductBySlug, products, categories } from "@/lib/products";

export const Route = createFileRoute("/menu/$slug")({
  loader: ({ params }) => {
    const product = getProductBySlug(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData
          ? `${loaderData.product.name} — Viśvam Drive-Thru`
          : "Menu — Viśvam Drive-Thru",
      },
      {
        name: "description",
        content:
          loaderData?.product.description ??
          "Indian kitchen classics, cooked to order and handed through the window at Viśvam.",
      },
      {
        property: "og:title",
        content: loaderData ? `${loaderData.product.name} — Viśvam` : "Viśvam Drive-Thru",
      },
      {
        property: "og:description",
        content: loaderData?.product.description ?? "Cooked to order, handed through the window.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MenuItemPage,
});

function MenuItemPage() {
  const { product } = Route.useLoaderData();
  const { add } = useCart();
  const [active, setActive] = useState(0);
  const related = products
    .filter((p) => p.category === product.category && p.slug !== product.slug)
    .slice(0, 3);
  const categoryLabel =
    categories.find((c) => c.slug === product.category)?.label ?? product.category;

  return (
    <SiteLayout>
      <div className="max-w-[1400px] mx-auto px-6 pt-10">
        <nav className="text-[10px] tracked text-muted-foreground flex gap-2">
          <Link to="/" className="hover:text-clay">Home</Link>
          <span>/</span>
          <Link to={`/${product.category}` as "/chai"} className="hover:text-clay">
            {categoryLabel}
          </Link>
          <span>/</span>
          <span className="text-ink">{product.name}</span>
        </nav>
      </div>

      <section className="max-w-[1400px] mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
        <div>
          <div className="bg-cream relative overflow-hidden aspect-[4/5]">
            {product.badge && (
              <span
                className={`absolute top-5 left-5 z-10 text-[9px] tracked px-2.5 py-1 ${
                  product.isNew || product.badge.startsWith("-")
                    ? "bg-ink text-white"
                    : "bg-white text-ink"
                }`}
              >
                {product.badge}
              </span>
            )}
            <img
              key={active}
              src={product.images[active]}
              alt={`${product.name} — view ${active + 1}`}
              width={912}
              height={1200}
              className="w-full h-full object-cover animate-fade-in"
            />
          </div>
          <div className="grid grid-cols-3 gap-3 mt-3">
            {product.images.map((img: string, i: number) => (
              <button
                key={img}
                onClick={() => setActive(i)}
                aria-label={`View image ${i + 1}`}
                className={`aspect-[4/5] overflow-hidden bg-cream border transition-colors ${
                  i === active ? "border-ink" : "border-transparent hover:border-border"
                }`}
              >
                <img
                  src={img}
                  alt={`${product.name} thumbnail ${i + 1}`}
                  width={300}
                  height={375}
                  loading="lazy"
                  className={`w-full h-full object-cover transition-opacity ${
                    i === active ? "opacity-100" : "opacity-70 hover:opacity-100"
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col justify-center max-w-md">
          <p className="text-[10px] tracked text-muted-foreground mb-4">{categoryLabel}</p>
          <h1 className="font-display italic text-4xl lg:text-5xl mb-4 leading-tight">
            {product.name}
          </h1>
          <p className="text-[10.5px] tracked text-muted-foreground mb-8">{product.tagline}</p>
          <p className="text-2xl mb-8 tabular-nums">{formatPrice(product.price)}</p>

          <div className="flex gap-8 border-y border-border py-5 mb-8 text-[10px] tracked">
            <span>{product.serving}</span>
            <span className="text-muted-foreground">{product.prepMinutes} min at the window</span>
            {product.spice && <span className="text-clay">{product.spice} heat</span>}
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed mb-10">
            {product.description}
          </p>

          <button
            onClick={() => add(product)}
            className="bg-ink text-white py-4 text-[11px] tracked font-semibold hover:bg-clay transition-colors mb-8"
          >
            Add to order — {formatPrice(product.price)}
          </button>

          <ul className="space-y-3 border-t border-border pt-8">
            {[
              "Cooked to order — never held under a lamp",
              "Free kulhad chai on orders over $25",
              "Order ahead, collect in under 5 minutes",
            ].map((t) => (
              <li key={t} className="flex gap-3 text-[12px]">
                <span className="text-clay">—</span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {related.length > 0 && (
        <section className="max-w-[1400px] mx-auto px-6 py-20 border-t border-border mt-12">
          <h2 className="font-display italic text-3xl mb-12">Goes well with</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-16">
            {related.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </section>
      )}
    </SiteLayout>
  );
}
