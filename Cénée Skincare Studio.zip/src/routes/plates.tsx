import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/plates")({
  head: () => ({
    meta: [
      { title: "Hot Plates — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Ghee masala dosa, khichdi bowls and paneer kathi rolls, cooked to order and boxed for the road at Viśvam.",
      },
      { property: "og:title", content: "Hot Plates — Viśvam Drive-Thru" },
      { property: "og:description", content: "Dosa, khichdi and rolls cooked to order." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <CategoryPage category="plates" />,
});
