import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/snacks")({
  head: () => ({
    meta: [
      { title: "Quick Bites — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Hand-folded samosas, Bombay vada pav and masala sweet corn — fried to order at the Viśvam drive-thru.",
      },
      { property: "og:title", content: "Quick Bites — Viśvam Drive-Thru" },
      { property: "og:description", content: "Samosa, vada pav and corn, fried to order." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <CategoryPage category="snacks" />,
});
