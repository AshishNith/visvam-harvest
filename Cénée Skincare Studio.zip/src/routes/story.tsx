import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import editorial from "@/assets/editorial-kitchen.jpg";

export const Route = createFileRoute("/story")({
  head: () => ({
    meta: [
      { title: "Our Story — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Viśvam is an Indian kitchen built around a drive-thru window: slow-cooked food, fast service, no compromise between the two.",
      },
      { property: "og:title", content: "Our Story — Viśvam Drive-Thru" },
      { property: "og:description", content: "Slow-cooked Indian food, served at speed." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Story,
});

function Story() {
  return (
    <SiteLayout>
      <section className="border-b border-border">
        <div className="max-w-[1400px] mx-auto px-6 py-24 lg:py-36 text-center">
          <p className="text-[10px] tracked text-muted-foreground mb-6">— Viśvam Kitchen</p>
          <h1 className="font-display italic text-5xl md:text-7xl lg:text-[96px] leading-[0.95] max-w-5xl mx-auto animate-fade-up">
            Slow food.<br />Handed over fast.
          </h1>
        </div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2">
        <div className="relative aspect-square lg:aspect-auto lg:min-h-[700px]">
          <img
            src={editorial}
            alt="Chai being pulled between two steel pots in the Viśvam kitchen"
            width={1200}
            height={1504}
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        <div className="bg-cream p-10 lg:p-20 flex flex-col justify-center gap-8">
          <div>
            <p className="text-[10px] tracked text-muted-foreground mb-4">01 — The problem</p>
            <h3 className="font-display italic text-3xl mb-4">
              Fast food stopped meaning fresh food.
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Drive-thru windows taught a whole country that speed costs flavour. Trays
              of food held under lamps, reheated, handed over grey.
            </p>
          </div>
          <div>
            <p className="text-[10px] tracked text-muted-foreground mb-4">02 — Our answer</p>
            <h3 className="font-display italic text-3xl mb-4">
              A working Indian kitchen behind a window.
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Batter fermented thirty-six hours. Chai boiled, not brewed. Samosas folded
              by hand in the morning and fried when your order lands. The lane is fast
              because the prep started at four in the morning — not because the food is.
            </p>
          </div>
          <div>
            <p className="text-[10px] tracked text-muted-foreground mb-4">03 — The promise</p>
            <h3 className="font-display italic text-3xl mb-4">
              Nothing waits more than ten minutes.
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              If it has been standing longer than ten minutes, it does not reach the
              window. Packaging is plant-based, spices are ground in-house, and the
              recipes come from three families who still argue about the chai ratio.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-background py-24">
        <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-px bg-border border border-border">
          {[
            ["4am", "the kitchen starts prep"],
            ["36h", "dosa batter fermentation"],
            ["<5min", "average wait at the window"],
            ["3", "lanes across the city"],
          ].map(([k, v]) => (
            <div key={k} className="bg-background p-10 text-center">
              <p className="font-display italic text-5xl mb-3">{k}</p>
              <p className="text-[10.5px] tracked text-muted-foreground max-w-[20ch] mx-auto">
                {v}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-ink text-white py-24 text-center">
        <h2 className="font-display italic text-4xl md:text-5xl max-w-2xl mx-auto px-6 mb-8">
          Pull in. We're already cooking.
        </h2>
        <Link
          to="/chai"
          className="inline-block bg-white text-ink px-10 py-4 text-[11px] tracked font-semibold hover:bg-sand transition-colors"
        >
          See the menu
        </Link>
      </section>
    </SiteLayout>
  );
}
