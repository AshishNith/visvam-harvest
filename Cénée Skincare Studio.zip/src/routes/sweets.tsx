import { createFileRoute } from "@tanstack/react-router";
import { CategoryPage } from "@/components/CategoryPage";

export const Route = createFileRoute("/sweets")({
  head: () => ({
    meta: [
      { title: "Sweets & Coolers — Viśvam Drive-Thru" },
      {
        name: "description",
        content:
          "Alphonso mango lassi, warm gulab jamun and kesar pista kulfi from the Viśvam drive-thru window.",
      },
      { property: "og:title", content: "Sweets & Coolers — Viśvam Drive-Thru" },
      { property: "og:description", content: "Lassi, jamun and kulfi built for the road." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <CategoryPage category="sweets" />,
});
